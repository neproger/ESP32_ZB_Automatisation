README file for installing the Kazak Win 95/98 keyboard layouts

1. Please make sure you run the Multiboot disk first.  

2. Open the Keyboards icon in Control Panel and go to the Language tab. At the bottom left is a check-box for "Enable indicator on task bar". If this has been selected then click to switch it off, then click on the "Apply" button.

3. From Start Menu\Run, type "A:\INSTALL" and click on "OK" to run the install program on this disk.

4. In the Keyboards installer, mentioned above, click on "Add" and select the required language from the list.   Then click on properties and choose the correct keyboard.  Normally this will be the GE keyboard with your language name.  For instance Turkmen GE.  For Russian there will be a choice of Russian or Russian OM GE.  The plain Russian is the national keyboard while the Russian OM GE is the transliterated one.

5.  Don't forget to turn the "Enable indicator on task bar" back on before closing the Control Panel\keyboards\language.  (See point 2).

----------------------------------------------------------------------------------------------

The documents enclosed are Word 97 files and htm files.  They are the keyboard layouts for various languages.  First install the CA-keys.ttf font, and then print out the file.   All of our keyboards are transliterated.  